


import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.Serializable;
import java.util.ArrayList;

public class ReadMessageActivity extends AppCompatActivity  {

    TextView senderName;
    TextView msgDesc;
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private Message message;
    private String key;

    ArrayList<Message> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_message);

        Toolbar toolbar2 = (Toolbar) findViewById(R.id.toolbar2); // get the reference of Toolbar
        toolbar2.setTitle("Read Message");
        setSupportActionBar(toolbar2);// Setting/replace toolbar as the ActionBar
        toolbar2.setLogo(R.drawable.ic_launcher);

        senderName = findViewById(R.id.readMesageSenderTV);
        msgDesc = findViewById(R.id.readMessageDesc);

        database = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();

        message =  (Message) getIntent().getExtras().get("inbox");
        key = getIntent().getExtras().getString("messageKey");

       senderName.setText(message.getSenderName());
       msgDesc.setText(message.getDesc());


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.replyIcon) {
            Toast.makeText(getApplicationContext(), "Compose Email", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this,ComposeMessageActivity.class);
            intent.putExtra("replyBack",message);
            startActivity(intent);
            return true;

        }

        if (id == R.id.discardIcon) {
            DatabaseReference rootRef = database.getReference();
            rootRef.child("users").child(mAuth.getCurrentUser().getUid()).child("inbox").child(message.getSenderId()).child("messages").child(key).removeValue();
            finish();
            return true;

        }

        return super.onOptionsItemSelected(item);
    }


}
