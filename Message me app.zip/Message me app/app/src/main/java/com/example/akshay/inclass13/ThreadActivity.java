



import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class ThreadActivity extends AppCompatActivity {

    ListView threadsList;
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    ArrayList<Message> inboxList;
    ThreadsAdapter threadsAdapter;
    ArrayList<String> keys;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thread);

        this.setTitle("Inbox");

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar); // get the reference of Toolbar
        toolbar.setTitle("Inbox");
        setSupportActionBar(toolbar);// Setting/replace toolbar as the ActionBar
        toolbar.setLogo(R.drawable.ic_launcher);
        threadsList = findViewById(R.id.listView);

        database = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();

        threadsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                inboxList.get(position).setRead(true);
                Log.d("demo","aadsfsf"+inboxList.get(position).toString());
                threadsAdapter.notifyDataSetChanged();
                String key = keys.get(position);
                database.getReference().child("users").child(mAuth.getCurrentUser().getUid())
                        .child("inbox").child(inboxList.get(position).getSenderId())
                        .child("messages").child(key).child("read").setValue(true);


                Intent intent = new Intent(ThreadActivity.this,ReadMessageActivity.class);
                intent.putExtra("inbox", (Serializable) inboxList.get(position));
                intent.putExtra("messageKey", keys.get(position));
                startActivity(intent);

            }
        });

        database.getReference().child("users").child(mAuth.getCurrentUser().getUid()).child("inbox")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Iterable iterable = dataSnapshot.getChildren();
                inboxList = new ArrayList<>();
                keys = new ArrayList<>();
                while (iterable.iterator().hasNext()) {

                    DataSnapshot ds = (DataSnapshot) iterable.iterator().next();
                    GenericTypeIndicator<HashMap<String,Message>> t = new GenericTypeIndicator<HashMap<String, Message>>() {};
                    HashMap<String, Message> dbMessagesMap = ds.child("messages").getValue(t);
                    ArrayList messages = new ArrayList(dbMessagesMap.values());
                    keys.addAll(dbMessagesMap.keySet());

                    inboxList.addAll(messages);
                }

                threadsAdapter = new ThreadsAdapter(ThreadActivity.this, R.layout.display_thread, inboxList);
                threadsList.setAdapter(threadsAdapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

          if (id == R.id.newEmail) {
            Toast.makeText(getApplicationContext(), "Compose Email", Toast.LENGTH_SHORT).show();
              Intent intent = new Intent(this,ComposeMessageActivity.class);
              startActivity(intent);
            return true;

        }

        if (id == R.id.logout) {
            Toast.makeText(getApplicationContext(), "Logging out ", Toast.LENGTH_SHORT).show();
            mAuth.signOut();
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            finish();
            return true;

        }

        return super.onOptionsItemSelected(item);
    }
}

