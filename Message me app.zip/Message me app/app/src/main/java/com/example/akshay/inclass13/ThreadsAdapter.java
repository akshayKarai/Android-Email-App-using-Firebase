


import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;


public class ThreadsAdapter extends ArrayAdapter<Message> {

    Activity context;
    private ArrayList<Message> messages;


    public ThreadsAdapter(@NonNull Activity context, int resource, @NonNull ArrayList<Message> messages) {
        super(context, resource,messages);
        this.context = context;
        this.messages = messages;
    }

    public View getView(int position, @Nullable View convertView, @NonNull final ViewGroup parent) {
        final ViewHolder viewHolder;
        final Message message = messages.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.display_thread, parent, false);
            viewHolder = new ViewHolder();

            viewHolder.UserNameTV = convertView.findViewById(R.id.userNameTV);
            viewHolder.DateTV = convertView.findViewById(R.id.dateTV);
            viewHolder.TimeTV = convertView.findViewById(R.id.timeTV);
            viewHolder.DescTV = convertView.findViewById(R.id.descriptionTV);
            viewHolder.bubble = convertView.findViewById(R.id.imageView);

            convertView.setTag(viewHolder);


        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        timeFormat.setTimeZone(TimeZone.getDefault());
        dateFormat.setTimeZone(TimeZone.getDefault());

            viewHolder.UserNameTV.setText(message.getSenderName());
            viewHolder.DateTV.setText(dateFormat.format(message.getDate()).toString());
            viewHolder.TimeTV.setText(timeFormat.format(message.getDate()).toString());
            //Log.d("demo", message.getDate().toString());
            viewHolder.DescTV.setText(message.getDesc());
            // Log.d("demo", message.toString());

            if(message.getRead()){
                viewHolder.bubble.setImageResource(R.drawable.circle_grey);
            }else{
                viewHolder.bubble.setImageResource(R.drawable.circle_blue);
            }


        notifyDataSetChanged();
        return convertView;

    }

    private static class ViewHolder {
        TextView UserNameTV, DateTV, TimeTV, DescTV;
        ImageView bubble;

    }

}
