


import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class ComposeMessageActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    ArrayList<User> array = new ArrayList<>();
    AlertDialog alertDialog;
    TextView receipient;
    User receiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compose_message);

        setTitle("Compose Message");

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        /*ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#E5E4E2")));*/

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#3F51B5")));

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        receipient = (TextView) findViewById(R.id.ComposeMessageUsers);

        final EditText composeEmail = findViewById(R.id.ComposeMessageDesc);
        Button buttonSend = findViewById(R.id.buttonSendCompose);
        final ImageButton receivers = findViewById(R.id.ComposeImageButton);

        Intent currentIntent = getIntent();

        if(currentIntent.getExtras() != null && currentIntent.getExtras().get("replyBack") != null){
            Message replyBackTo = (Message) currentIntent.getExtras().get("replyBack");
            receipient.setText(replyBackTo.getSenderName());
            receiver = new User();
            receiver.setUid(replyBackTo.getSenderId());
            receiver.setFirst(replyBackTo.getSenderName().split(" ")[0]);
            receiver.setLast(replyBackTo.getSenderName().split(" ")[1]);
            receivers.setVisibility(View.INVISIBLE);

        }else{
            receivers.setVisibility(View.VISIBLE);
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {

            String name = user.getDisplayName();
            String email = user.getEmail();
            String uid = user.getUid();

            Log.d("demo",name + " "+email+" "+ uid);
        }

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference usersdRef = rootRef.child("users");

        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    User user = ds.child("details").getValue(User.class);
                    Log.d("bisket", user.toString());
                    array.add(user);

                }

                Log.d("users", String.valueOf(array));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
        usersdRef.addValueEventListener(eventListener);

        receivers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(ComposeMessageActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                View convertView = (View) inflater.inflate(R.layout.custom, null);
                alertDialog.setView(convertView);
                alertDialog.setTitle("Users");

                ListView lv = (ListView) convertView.findViewById(R.id.listView1);

                ArrayAdapter userAdapter = new CustomAdapter(ComposeMessageActivity.this,array);
                lv.setAdapter(userAdapter);
                final AlertDialog ad = alertDialog.create();
                ad.show();
                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        receiver = array.get(position);
                        receipient.setText(receiver.getFirst()+" "+receiver.getLast());
                        ad.dismiss();
                    }
                });

            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(receiver != null) {

                    String composedEmail = composeEmail.getText().toString();
                    Message message = new Message();
                    message.setDesc(composedEmail);
                    message.setDate(new Date());
                    message.setSenderId(mAuth.getCurrentUser().getUid());
                    message.setSenderName(mAuth.getCurrentUser().getDisplayName());
                    message.setRead(false);
                    message.setReceiverId(receiver.getUid());
                    message.setReceiverName(receiver.getFirst() + " " + receiver.getLast());
                    //message.set receiver details
                    Log.d("bisket", message.toString());
                    database.getReference().child("users").child(receiver.getUid()).child("inbox")
                            .child(mAuth.getCurrentUser().getUid()).child("messages").push().setValue(message);

                    Toast.makeText(ComposeMessageActivity.this, "Sent", Toast.LENGTH_LONG).show();
                    finish();
                }else{
                    Toast.makeText(ComposeMessageActivity.this,"Please select a receipient", Toast.LENGTH_LONG).show();
                }


            }
        });
    }
}
