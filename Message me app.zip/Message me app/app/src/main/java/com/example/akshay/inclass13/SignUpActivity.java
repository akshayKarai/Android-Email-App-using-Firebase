

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;

public class SignUpActivity extends AppCompatActivity {

    EditText fname, lname, email;
    EditText pass, repass;
    Button cancel, signupButton;
    String sender, receiver = "hey",desc = "wassp";
    Date date;
    Boolean isRead;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        this.setTitle("Sign Up");

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);


        fname = findViewById(R.id.FnameTV2);
        lname = findViewById(R.id.LnameTV2);
        email = findViewById(R.id.EmailTV2);
        pass = findViewById(R.id.PassTV2);
        repass = findViewById(R.id.RePassTV2);
        cancel = findViewById(R.id.buttonCancel2);
        signupButton = findViewById(R.id.buttonSignUp2);
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fname.getText().toString().isEmpty() || lname.getText().toString().isEmpty() || email.getText().toString().isEmpty() || pass.getText().toString().isEmpty() || repass.getText().toString().isEmpty()){
                    Toast.makeText(SignUpActivity.this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                }
                else if(!pass.getText().toString().equals(repass.getText().toString())){
                    Toast.makeText(SignUpActivity.this, "Password fields do not match", Toast.LENGTH_SHORT).show();
                }
                else if(pass.getText().toString().length() < 6){
                    Toast.makeText(SignUpActivity.this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                }
                else{
                    performSignup(email.getText().toString(), pass.getText().toString(), fname.getText().toString(), lname.getText().toString());
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUpActivity.this, MainActivity.class);

                startActivity(intent);
                finish();
            }
        });

    }

    public void performSignup(final String email, final String password, final String fname, final String lname){

        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    final User user = new User(fname, lname, email, mAuth.getCurrentUser().getUid());
                    sender = fname + lname;
                    database.getReference().child("users").child(user.getUid()).child("details").setValue(user);

                    UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                            .setDisplayName(user.getFirst() + " " + user.getLast()).build();
                    mAuth.getCurrentUser().updateProfile(profileUpdates).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){

                            }
                            else{

                            }
                            Toast.makeText(SignUpActivity.this, "Signup is successful", Toast.LENGTH_SHORT).show();
                            mAuth.signInWithEmailAndPassword(user.getEmail(), user.getUid());
                            Intent intent = new Intent(SignUpActivity.this, ThreadActivity.class);
                            startActivity(intent);

                        }
                    });
                } else {

                    Toast.makeText(SignUpActivity.this, task.getException().getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}

